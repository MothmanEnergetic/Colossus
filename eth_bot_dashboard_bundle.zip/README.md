# ETH Arbitrage Bot Dashboard

## Features

- Firebase-authenticated user access
- Token refresh tracking with email/webhook alerts
- Signal feed with filters, logging, and backtest upload
- Admin dashboard with IP/device tracing
- Streamlit-based UI

## Deploy

```bash
docker build -t eth-bot-dashboard .
docker run -p 8501:8501 eth-bot-dashboard
```

## Setup

1. Create a Firebase project, enable email/password login
2. Download the service account JSON as `firebase_credentials.json`
3. Rename and fill in `.streamlit/secrets.toml`
4. Deploy locally or to Streamlit Cloud
